const MAP_W  = 16;
const MAP_H  = 12;
const TILE   = 62;

const I18N = {
    fr: {
        subtitle:"Jeu de stratégie de conquête", mode:"Mode de jeu",
        vs_ia:"👤 vs IA", vs_player:"👥 vs Joueur",
        ai_level:"Niveau de l'IA", easy:"🟢 Facile", medium:"🟡 Moyen", hard:"🔴 Difficile",
        map:"Carte", map_europe:"Europe Médiévale", map_europe_desc:"6 camps · rivières",
        map_afrique:"Afrique Désertique", map_afrique_desc:"6 camps · rochers",
        map_amerique:"Archipel Américain", map_amerique_desc:"5 camps · mer",
        start:"▶ Lancer la partie", player1:"Joueur 1 🔵", produce:"Produire une unité",
        infantry:"⚔ Infantry — 40🪙", archer:"🏹 Archer — 50🪙",
        assassin:"🗡 Assassin — 60🪙", mage:"⚡ Mage — 70🪙", tank:"🛡 Tank — 80🪙",
        end_turn:"▶ Fin de tour", back_menu:"⟵ Menu", journal:"Journal",
        turn:"Tour", victory:"Victoire !", defeat:"Défaite...",
        player_wins:"Joueur {n} gagne !", camps_conquered:"camps conquis",
        ia_level:"IA niveau", player_turn:"Tour du Joueur",
    },
    en: {
        subtitle:"Conquest strategy game", mode:"Game mode",
        vs_ia:"👤 vs AI", vs_player:"👥 vs Player",
        ai_level:"AI Level", easy:"🟢 Easy", medium:"🟡 Medium", hard:"🔴 Hard",
        map:"Map", map_europe:"Medieval Europe", map_europe_desc:"6 camps · rivers",
        map_afrique:"Desert Africa", map_afrique_desc:"6 camps · rocks",
        map_amerique:"American Archipelago", map_amerique_desc:"5 camps · sea",
        start:"▶ Start game", player1:"Player 1 🔵", produce:"Produce a unit",
        infantry:"⚔ Infantry — 40🪙", archer:"🏹 Archer — 50🪙",
        assassin:"🗡 Assassin — 60🪙", mage:"⚡ Mage — 70🪙", tank:"🛡 Tank — 80🪙",
        end_turn:"▶ End turn", back_menu:"⟵ Menu", journal:"Log",
        turn:"Turn", victory:"Victory !", defeat:"Defeat...",
        player_wins:"Player {n} wins !", camps_conquered:"camps conquered",
        ia_level:"AI level", player_turn:"Player turn",
    },
    es: {
        subtitle:"Juego de estrategia de conquista", mode:"Modo de juego",
        vs_ia:"👤 vs IA", vs_player:"👥 vs Jugador",
        ai_level:"Nivel de IA", easy:"🟢 Fácil", medium:"🟡 Medio", hard:"🔴 Difícil",
        map:"Mapa", map_europe:"Europa Medieval", map_europe_desc:"6 campos · ríos",
        map_afrique:"África Desértica", map_afrique_desc:"6 campos · rocas",
        map_amerique:"Archipiélago Americano", map_amerique_desc:"5 campos · mar",
        start:"▶ Iniciar partida", player1:"Jugador 1 🔵", produce:"Producir unidad",
        infantry:"⚔ Infantería — 40🪙", archer:"🏹 Arquero — 50🪙",
        assassin:"🗡 Asesino — 60🪙", mage:"⚡ Mago — 70🪙", tank:"🛡 Tanque — 80🪙",
        end_turn:"▶ Fin de turno", back_menu:"⟵ Menú", journal:"Registro",
        turn:"Turno", victory:"¡Victoria !", defeat:"Derrota...",
        player_wins:"¡Jugador {n} gana !", camps_conquered:"campos conquistados",
        ia_level:"Nivel IA", player_turn:"Turno del Jugador",
    }
};

let currentLang = "fr";
function t(key, vars) {
    let str = (I18N[currentLang]||I18N.fr)[key]||key;
    if (vars) Object.keys(vars).forEach(k => { str = str.replace("{"+k+"}", vars[k]); });
    return str;
}
function applyLang() {
    document.querySelectorAll("[data-i18n]").forEach(el => {
        el.textContent = t(el.getAttribute("data-i18n"));
    });
    document.querySelectorAll(".btn-lang,.btn-lang-sm").forEach(b => {
        b.classList.toggle("active", b.dataset.lang === currentLang);
    });
}
document.querySelectorAll(".btn-lang,.btn-lang-sm").forEach(b => {
    b.addEventListener("click", () => {
        currentLang = b.dataset.lang;
        applyLang();
        if (gameState) updateHUD();
    });
});

const C = {
    grass1:"#3a5c2a", grass2:"#2e4d20",
    desert1:"#c8a84a", desert2:"#b89438",
    water:"#1a5f8a", rock:"#5a4a3a",
    grid:"rgba(0,0,0,0.12)",
    p1:"#4a9eff", p2:"#ff4a4a",
    select:"#ffd700",
    camp1:"#1a3a7a", camp2:"#7a1a1a", campN:"#3a3a3a",
};
const UNIT_RING = {
    infantry:"#aaaaff", archer:"#5bbfff",
    tank:"#88aaff", mage:"#cc88ff", assassin:"#ff9955", boat:"#44ccff",
};
const UNIT_MAX_HP  = { infantry:100, archer:100, tank:150, mage:90, assassin:80, boat:120 };
const UNIT_COST    = { infantry:40, archer:50, assassin:60, mage:70, tank:80, boat:60 };
const ATTACK_RANGE = { infantry:1, archer:3, mage:2, assassin:1, tank:1, boat:2 };

const sounds = {};
["click","move","attack","capture","produce","victory","defeat","error"].forEach(n => {
    const a = new Audio(`sounds/${n}.mp3`); a.volume = 0.4; sounds[n] = a;
});
function playSound(n) { try { sounds[n].currentTime=0; sounds[n].play(); } catch(e){} }

let canvas, ctx, minimap, miniCtx;
let gameState    = null;
let selectedUnit = null;
let logMessages  = [];
let gameMode     = "pve";
let aiLevel      = 1;
let selectedMap  = "europe";
let spellMode    = false;
let boatMode     = false;
let selectedBoat = null;

document.querySelectorAll(".btn-mode").forEach(b => {
    b.addEventListener("click", () => {
        document.querySelectorAll(".btn-mode").forEach(x => x.classList.remove("active"));
        b.classList.add("active");
        gameMode = b.dataset.mode;
        document.getElementById("ai-options").style.display = gameMode==="pve" ? "block" : "none";
        document.getElementById("hud-p2-label").textContent = gameMode==="pvp" ? t("vs_player")+" 🔴" : "IA 🔴";
    });
});
document.querySelectorAll(".btn-ai").forEach(b => {
    b.addEventListener("click", () => {
        document.querySelectorAll(".btn-ai").forEach(x => x.classList.remove("active"));
        b.classList.add("active");
        aiLevel = parseInt(b.dataset.level);
    });
});
document.querySelectorAll(".map-card").forEach(b => {
    b.addEventListener("click", () => {
        document.querySelectorAll(".map-card").forEach(x => x.classList.remove("active"));
        b.classList.add("active");
        selectedMap = b.dataset.map;
    });
});

async function startGame() {
    const res = await fetch("http://localhost:5000/new_game", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ map: selectedMap, mode: gameMode, ai_level: aiLevel })
    });
    const data = await res.json();
    gameState = data.state;
    gameState.units.forEach(u => { if (!u.maxhp) u.maxhp = UNIT_MAX_HP[u.type]||100; });
    document.getElementById("screen-menu").style.display = "none";
    document.getElementById("screen-game").style.display = "block";
    canvas  = document.getElementById("gameCanvas");
    ctx     = canvas.getContext("2d");
    minimap = document.getElementById("minimap");
    miniCtx = minimap.getContext("2d");
    canvas.addEventListener("click", async e => {
        const rect = canvas.getBoundingClientRect();
        await handleCanvasClick(e, rect);
    });
    logMessages = []; selectedUnit = null; spellMode = false; boatMode = false; selectedBoat = null;
    addLog("=== " + t("start") + " ===");
    draw();
}

function backToMenu() {
    document.getElementById("screen-game").style.display = "none";
    document.getElementById("screen-end").style.display  = "none";
    document.getElementById("screen-menu").style.display = "flex";
    applyLang();
}

function draw() {
    if (!ctx || !gameState) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawGrass(); drawWater(); drawObstacles(); drawGrid();
    drawCamps(); drawMoveRange(); drawUnits();
    drawMinimap(); updateHUD();
}

function isDesert() { return gameState.map_name === "afrique"; }

function drawGrass() {
    for (let y=0;y<MAP_H;y++) for (let x=0;x<MAP_W;x++) {
        ctx.fillStyle = (x+y)%2===0 ? (isDesert()?C.desert1:C.grass1) : (isDesert()?C.desert2:C.grass2);
        ctx.fillRect(x*TILE, y*TILE, TILE, TILE);
    }
}
function drawWater() {
    gameState.water.forEach(w => {
        ctx.fillStyle=C.water; ctx.fillRect(w.x*TILE,w.y*TILE,TILE,TILE);
        ctx.fillStyle="rgba(255,255,255,0.07)";
        ctx.fillRect(w.x*TILE+5,w.y*TILE+10,TILE-10,3);
        ctx.fillRect(w.x*TILE+10,w.y*TILE+24,TILE-20,2);
    });
}
function drawObstacles() {
    gameState.obstacles.forEach(o => {
        ctx.fillStyle=C.rock; ctx.fillRect(o.x*TILE,o.y*TILE,TILE,TILE);
        ctx.fillStyle="rgba(255,255,255,0.06)";
        ctx.fillRect(o.x*TILE+5,o.y*TILE+6,14,8);
        ctx.fillRect(o.x*TILE+22,o.y*TILE+18,10,6);
    });
}
function drawGrid() {
    ctx.strokeStyle=C.grid; ctx.lineWidth=0.5;
    for(let x=0;x<=MAP_W;x++){ctx.beginPath();ctx.moveTo(x*TILE,0);ctx.lineTo(x*TILE,MAP_H*TILE);ctx.stroke();}
    for(let y=0;y<=MAP_H;y++){ctx.beginPath();ctx.moveTo(0,y*TILE);ctx.lineTo(MAP_W*TILE,y*TILE);ctx.stroke();}
}
function drawCamps() {
    gameState.camps.forEach(c => {
        const col=c.owner===1?C.camp1:c.owner===2?C.camp2:C.campN;
        const border=c.owner===1?C.p1:c.owner===2?C.p2:"#666";
        ctx.fillStyle=col;
        ctx.beginPath(); ctx.roundRect(c.x*TILE+4,c.y*TILE+4,TILE-8,TILE-8,5); ctx.fill();
        ctx.strokeStyle=border; ctx.lineWidth=2; ctx.stroke();
        ctx.fillStyle="rgba(255,255,255,0.15)";
        ctx.beginPath(); ctx.arc(c.x*TILE+25,c.y*TILE+20,8,0,Math.PI*2); ctx.fill();
        const fx=c.x*TILE+13,fy=c.y*TILE+8;
        ctx.strokeStyle="#fff"; ctx.lineWidth=2;
        ctx.beginPath(); ctx.moveTo(fx,fy); ctx.lineTo(fx,fy+24); ctx.stroke();
        ctx.fillStyle=c.owner===1?C.p1:c.owner===2?C.p2:"#888";
        ctx.beginPath(); ctx.moveTo(fx,fy); ctx.lineTo(fx+14,fy+6); ctx.lineTo(fx,fy+12); ctx.closePath(); ctx.fill();
        if(c.is_port){
            ctx.fillStyle="rgba(100,200,255,0.9)";
            ctx.font="bold 13px sans-serif"; ctx.textAlign="center";
            ctx.fillText("⚓",c.x*TILE+TILE-10,c.y*TILE+TILE-6);
        }
    });
}
function drawMoveRange() {
    if (!selectedUnit) return;
    const moveRange=3, attackRange=ATTACK_RANGE[selectedUnit.type]||1;
    for(let dy=-moveRange;dy<=moveRange;dy++) for(let dx=-moveRange;dx<=moveRange;dx++) {
        if(Math.abs(dx)+Math.abs(dy)>moveRange) continue;
        const tx=selectedUnit.x+dx,ty=selectedUnit.y+dy;
        if(tx<0||ty<0||tx>=MAP_W||ty>=MAP_H) continue;
        ctx.fillStyle="rgba(255,215,0,0.12)"; ctx.fillRect(tx*TILE+1,ty*TILE+1,TILE-2,TILE-2);
    }
    for(let dy=-attackRange;dy<=attackRange;dy++) for(let dx=-attackRange;dx<=attackRange;dx++) {
        if(Math.abs(dx)+Math.abs(dy)>attackRange) continue;
        if(Math.abs(dx)+Math.abs(dy)<=moveRange) continue;
        const tx=selectedUnit.x+dx,ty=selectedUnit.y+dy;
        if(tx<0||ty<0||tx>=MAP_W||ty>=MAP_H) continue;
        ctx.fillStyle="rgba(255,60,60,0.18)"; ctx.fillRect(tx*TILE+1,ty*TILE+1,TILE-2,TILE-2);
    }
    if(spellMode){
        ctx.strokeStyle="#aa88ff"; ctx.lineWidth=3;
        ctx.strokeRect(selectedUnit.x*TILE+1,selectedUnit.y*TILE+1,TILE-2,TILE-2);
    }
    if(boatMode&&selectedBoat){
        ctx.strokeStyle="#44ccff"; ctx.lineWidth=3;
        ctx.strokeRect(selectedBoat.x*TILE+1,selectedBoat.y*TILE+1,TILE-2,TILE-2);
    }
}
function drawUnits() {
    gameState.units.forEach(u => {
        const cx=u.x*TILE+25, cy=u.y*TILE+22;
        if(selectedUnit&&selectedUnit.id===u.id){
            ctx.strokeStyle=C.select; ctx.lineWidth=3;
            ctx.strokeRect(u.x*TILE+1,u.y*TILE+1,TILE-2,TILE-2);
            ctx.fillStyle="rgba(255,215,0,0.08)";
            ctx.fillRect(u.x*TILE+1,u.y*TILE+1,TILE-2,TILE-2);
        }
        if(u.shield){
            ctx.strokeStyle="#88aaff"; ctx.lineWidth=2;
            ctx.strokeRect(u.x*TILE+2,u.y*TILE+2,TILE-4,TILE-4);
        }
        ctx.fillStyle="rgba(0,0,0,0.25)";
        ctx.beginPath(); ctx.ellipse(cx+2,cy+3,14,8,0,0,Math.PI*2); ctx.fill();
        const ring=UNIT_RING[u.type]||(u.team===1?C.p1:C.p2);
        ctx.fillStyle=u.team===1?"#1a3a5a":"#5a1a1a";
        ctx.beginPath(); ctx.arc(cx,cy,16,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle=ring; ctx.lineWidth=2.5; ctx.stroke();
        drawUnitIcon(u.type,cx,cy);
        drawHPBar(u,cx,cy);
        ctx.font="bold 10px sans-serif"; ctx.textAlign="center";
        ctx.fillStyle="#fff"; ctx.fillText(u.hp,cx,cy+32);
        if(u.spell_used){
            ctx.font="10px sans-serif"; ctx.fillStyle="#aa88ff";
            ctx.fillText("✨",cx+12,cy-10);
        }
        if(u.passenger){
            ctx.font="10px sans-serif"; ctx.fillStyle="#ffdd88";
            ctx.fillText("👤",cx-12,cy-10);
        }
    });
}
function drawUnitIcon(type,cx,cy) {
    ctx.strokeStyle="#fff"; ctx.fillStyle="#fff";
    ctx.lineWidth=2; ctx.lineCap="round"; ctx.lineJoin="round";
    if(type==="archer"){
        ctx.beginPath(); ctx.arc(cx-2,cy,8,Math.PI*0.65,Math.PI*1.35,true); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx-2,cy-8); ctx.lineTo(cx-2,cy+8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx-5,cy); ctx.lineTo(cx+7,cy); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx+7,cy); ctx.lineTo(cx+4,cy-3); ctx.moveTo(cx+7,cy); ctx.lineTo(cx+4,cy+3); ctx.stroke();
    } else if(type==="tank"){
        ctx.beginPath(); ctx.moveTo(cx,cy-9); ctx.lineTo(cx+7,cy-4); ctx.lineTo(cx+7,cy+3); ctx.lineTo(cx,cy+9); ctx.lineTo(cx-7,cy+3); ctx.lineTo(cx-7,cy-4); ctx.closePath(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx,cy-4); ctx.lineTo(cx,cy+4); ctx.moveTo(cx-4,cy); ctx.lineTo(cx+4,cy); ctx.stroke();
    } else if(type==="mage"){
        [0,45,90,135].forEach(a=>{
            const r=a*Math.PI/180;
            ctx.beginPath(); ctx.moveTo(cx+Math.cos(r)*3,cy+Math.sin(r)*3); ctx.lineTo(cx+Math.cos(r)*9,cy+Math.sin(r)*9); ctx.stroke();
        });
        ctx.beginPath(); ctx.arc(cx,cy,3,0,Math.PI*2); ctx.fill();
    } else if(type==="assassin"){
        ctx.beginPath(); ctx.moveTo(cx-5,cy+7); ctx.lineTo(cx+5,cy-7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx-4,cy+2); ctx.lineTo(cx+4,cy-2); ctx.stroke();
    } else if(type==="boat"){
        ctx.beginPath(); ctx.moveTo(cx-10,cy+4); ctx.lineTo(cx+10,cy+4); ctx.lineTo(cx+8,cy+9); ctx.lineTo(cx-8,cy+9); ctx.closePath(); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(cx,cy+4); ctx.lineTo(cx,cy-8); ctx.lineTo(cx+8,cy); ctx.closePath(); ctx.stroke();
    } else {
        ctx.beginPath(); ctx.moveTo(cx,cy-8); ctx.lineTo(cx-5,cy+6); ctx.lineTo(cx+5,cy+6); ctx.closePath(); ctx.stroke();
        ctx.beginPath(); ctx.arc(cx,cy-10,4,0,Math.PI*2); ctx.stroke();
    }
}
function drawHPBar(u,cx,cy) {
    const maxHp=u.maxhp||UNIT_MAX_HP[u.type]||100;
    const pct=Math.max(0,u.hp/maxHp);
    const bw=36,bh=5,bx=cx-bw/2,by=cy+18;
    ctx.fillStyle="#222"; ctx.fillRect(bx,by,bw,bh);
    ctx.fillStyle=pct>0.5?"#4caf50":pct>0.25?"#ff9800":"#f44336";
    ctx.fillRect(bx,by,bw*pct,bh);
    ctx.strokeStyle="rgba(0,0,0,0.4)"; ctx.lineWidth=0.5; ctx.strokeRect(bx,by,bw,bh);
}
function drawMinimap() {
    miniCtx.clearRect(0,0,minimap.width,minimap.height);
    miniCtx.fillStyle="#1e3212"; miniCtx.fillRect(0,0,minimap.width,minimap.height);
    const sx=minimap.width/MAP_W,sy=minimap.height/MAP_H;
    gameState.water.forEach(w=>{miniCtx.fillStyle=C.water;miniCtx.fillRect(w.x*sx,w.y*sy,sx,sy);});
    gameState.obstacles.forEach(o=>{miniCtx.fillStyle=C.rock;miniCtx.fillRect(o.x*sx,o.y*sy,sx,sy);});
    gameState.camps.forEach(c=>{miniCtx.fillStyle=c.owner===1?C.p1:c.owner===2?C.p2:"#666";miniCtx.fillRect(c.x*sx,c.y*sy,sx+1,sy+1);});
    gameState.units.forEach(u=>{miniCtx.fillStyle=u.team===1?C.p1:C.p2;miniCtx.beginPath();miniCtx.arc(u.x*sx+sx/2,u.y*sy+sy/2,3,0,Math.PI*2);miniCtx.fill();});
}

function updateHUD() {
    const mapNames={"europe":t("map_europe"),"afrique":t("map_afrique"),"amerique":t("map_amerique")};
    document.getElementById("hud-mapname").textContent=mapNames[gameState.map_name]||"";
    document.getElementById("hud-turn").textContent=t("turn")+" "+gameState.turn;
    document.getElementById("hud-current").textContent=gameState.mode==="pvp"
        ?t("player_turn")+" "+gameState.current_player
        :t("ia_level")+" "+gameState.ai_level;
    const g=gameState.gold||{};
    document.getElementById("hud-gold1").textContent=(g[1]||g["1"]||0)+" 🪙";
    document.getElementById("hud-gold2").textContent=(g[2]||g["2"]||0)+" 🪙";
    const c1=gameState.camps.filter(c=>c.owner===1).length;
    const c2=gameState.camps.filter(c=>c.owner===2).length;
    const total=gameState.camps.length;
    document.getElementById("hud-camps1").textContent=c1+"/"+total+" camps";
    document.getElementById("hud-camps2").textContent=c2+"/"+total+" camps";
    const spellBtn=document.querySelector(".btn-spell");
    if(spellBtn&&selectedUnit){
        const fresh=gameState.units.find(u=>u.id===selectedUnit.id);
        spellBtn.classList.toggle("used",!!(fresh&&fresh.spell_used));
    }
    document.getElementById("hud-log").innerHTML=
        logMessages.slice(-10).reverse().map(m=>`<div class="${m.cls||''}">${m.text}</div>`).join("");
    applyLang();
}
function addLog(text,cls=""){logMessages.push({text,cls});}

async function handleCanvasClick(e,rect) {
    if(!gameState) return;
    const gx=Math.floor((e.clientX-rect.left)/TILE);
    const gy=Math.floor((e.clientY-rect.top)/TILE);
    playSound("click");
    const activeTeam=gameState.mode==="pvp"?gameState.current_player:1;

    // Mode débarquement
    if(boatMode&&selectedBoat){
        await disembark(selectedBoat.id,gx,gy);
        return;
    }

    // Mode sort
    if(spellMode&&selectedUnit){
        const target=gameState.units.find(u=>u.x===gx&&u.y===gy&&u.team!==activeTeam);
        if(target){
            await useSpell(selectedUnit.id,target.id);
            selectedUnit=null;
        } else {
            spellMode=false;
            document.getElementById("spell-info").textContent="";
            addLog("Sort annulé");
        }
        return;
    }

    const ally=gameState.units.find(u=>u.x===gx&&u.y===gy&&u.team===activeTeam);
    if(ally){
        selectedUnit=ally;
        if(ally.type==="boat"&&ally.passenger){
            selectedBoat=ally;
        } else {
            selectedBoat=null;
        }
        draw(); return;
    }
    const enemy=gameState.units.find(u=>u.x===gx&&u.y===gy&&u.team!==activeTeam);
    if(enemy&&selectedUnit){await attackUnit(selectedUnit.id,enemy.id);selectedUnit=null;return;}
    if(selectedUnit){await moveUnit(selectedUnit.id,gx,gy);selectedUnit=null;}
}

async function loadState() {
    const res=await fetch("http://localhost:5000/state");
    const data=await res.json();
    data.units.forEach(u=>{if(!u.maxhp)u.maxhp=UNIT_MAX_HP[u.type]||100;});
    gameState=data;
}

async function moveUnit(id,x,y) {
    const res=await fetch("http://localhost:5000/move_unit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,x,y})});
    const data=await res.json();
    if(data.status==="ok"){
        if(data.embarked){
            playSound("move");
            addLog("⚓ Unité embarquée sur le bateau !","log-capture");
        } else {
            playSound(data.captured?"capture":"move");
            if(data.captured) addLog("⚑ Camp capturé !","log-capture");
            else addLog("Déplacé en ("+x+","+y+")");
        }
    } else {playSound("error");addLog("Impossible : "+data.msg);}
    await loadState();draw();checkVictory();
}

async function attackUnit(attacker,target) {
    const res=await fetch("http://localhost:5000/attack",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({attacker,target})});
    const data=await res.json();
    if(data.status==="ok"){playSound("attack");addLog("⚔ -"+data.damage+" PV"+(data.killed?" (tué)":""),"log-attack");}
    else{playSound("error");addLog("Hors portée !");}
    await loadState();draw();checkVictory();
}

async function produceUnit(type) {
    const activeTeam=gameState.mode==="pvp"?gameState.current_player:1;
    let camp;
    if(type==="boat"){
        camp=gameState.camps.find(c=>c.owner===activeTeam&&c.is_port);
        if(!camp){playSound("error");addLog("Capture d'abord un port (⚓) !");return;}
    } else {
        camp=gameState.camps.find(c=>c.owner===activeTeam);
        if(!camp){playSound("error");addLog("Aucun camp possédé !");return;}
    }
    const g=gameState.gold||{};
    const myGold=g[activeTeam]||g[String(activeTeam)]||0;
    if(myGold<(UNIT_COST[type]||50)){playSound("error");addLog("Pas assez d'or !");return;}
    const res=await fetch("http://localhost:5000/produce_unit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({x:camp.x,y:camp.y,type,team:activeTeam})});
    const data=await res.json();
    if(data.status==="ok"){playSound("produce");addLog("⚓ "+type+" produit !","log-produce");}
    else{playSound("error");addLog("Impossible : "+(data.msg||"erreur"));}
    await loadState();draw();
}

async function disembark(boatId,x,y) {
    const res=await fetch("http://localhost:5000/disembark",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({boat_id:boatId,x,y})});
    const data=await res.json();
    if(data.status==="ok"){
        playSound(data.captured?"capture":"move");
        if(data.captured) addLog("⚑ Débarquement + camp capturé !","log-capture");
        else addLog("⚓ Débarquement réussi !");
    } else {playSound("error");addLog("Débarquement impossible : "+(data.msg||"erreur"));}
    boatMode=false; selectedBoat=null;
    document.getElementById("boat-info").textContent="";
    await loadState();draw();checkVictory();
}

async function endTurn() {
    const activeTeam=gameState.mode==="pvp"?gameState.current_player:1;
    const res=await fetch("http://localhost:5000/end_turn",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({team:activeTeam})});
    const data=await res.json();
    if(data.tower_log)data.tower_log.forEach(m=>addLog("🗼 "+m,"log-tower"));
    if(data.region_log)data.region_log.forEach(m=>addLog("🌍 "+m,"log-capture"));
    await loadState();
    if(gameState.mode==="pve"){
        const aiRes=await fetch("http://localhost:5000/ai_turn",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({})});
        const aiData=await aiRes.json();
        if(aiData.log)aiData.log.forEach(m=>addLog("🤖 "+m,"log-attack"));
        await loadState();
    }
    spellMode=false; boatMode=false; selectedBoat=null;
    document.getElementById("spell-info").textContent="";
    document.getElementById("boat-info").textContent="";
    addLog("=== "+t("turn")+" "+gameState.turn+" ===");
    draw();checkVictory();
}

function activateSpell() {
    if(!selectedUnit){addLog("Sélectionne d'abord une unité !");return;}
    const fresh=gameState.units.find(u=>u.id===selectedUnit.id);
    if(!fresh){addLog("Unité introuvable !");return;}
    selectedUnit=fresh;
    if(selectedUnit.spell_used){addLog("Sort déjà utilisé ce tour !");return;}
    const spells={
        archer:"Tir de précision — clique sur une cible",
        mage:"Boule de feu — explose autour du mage",
        tank:"Bouclier — actif immédiatement",
        assassin:"Frappe mortelle — clique sur une cible",
        infantry:"Cri de guerre — soigne les alliés adjacents"
    };
    if(selectedUnit.type==="tank"||selectedUnit.type==="infantry"){
        useSpell(selectedUnit.id,null); return;
    }
    spellMode=true;
    document.getElementById("spell-info").textContent=spells[selectedUnit.type]||"";
    addLog("✨ Mode sort — clique sur une cible");
    draw();
}

async function useSpell(unitId,targetId) {
    const res=await fetch("http://localhost:5000/use_spell",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:unitId,target_id:targetId})});
    const data=await res.json();
    if(data.status==="ok"){playSound("attack");addLog("✨ "+data.msg,"log-capture");}
    else{playSound("error");addLog("Sort impossible : "+data.msg);}
    spellMode=false;
    document.getElementById("spell-info").textContent="";
    await loadState();draw();checkVictory();
}

function activateDisembark() {
    if(!selectedUnit||selectedUnit.type!=="boat"){
        addLog("Sélectionne d'abord un bateau !"); return;
    }
    const fresh=gameState.units.find(u=>u.id===selectedUnit.id);
    if(!fresh){addLog("Bateau introuvable !"); return;}
    if(!fresh.passenger){addLog("Aucun passager dans le bateau !"); return;}
    selectedBoat=fresh;
    boatMode=true;
    document.getElementById("boat-info").textContent="Clique sur une case terrestre adjacente";
    addLog("⚓ Mode débarquement — clique une case terrestre");
    draw();
}

function checkVictory() {
    const p1camps=gameState.camps.filter(c=>c.owner===1).length;
    const p2camps=gameState.camps.filter(c=>c.owner===2).length;
    const total=gameState.camps.length;
    const p1alive=gameState.units.some(u=>u.team===1);
    const p2alive=gameState.units.some(u=>u.team===2);
    let winner=null;
    if(!p2alive||p2camps===0)winner=1;
    else if(!p1alive||p1camps===0)winner=2;
    else if(p1camps===total)winner=1;
    else if(p2camps===total)winner=2;
    if(winner){
        const winnerCamps=gameState.camps.filter(c=>c.owner===winner).length;
        saveScore(winner,winnerCamps);
        showEndScreen(winner);
    }
}

function showEndScreen(winner) {
    document.getElementById("end-icon").textContent=winner===1?"🏆":"💀";
    document.getElementById("end-title").textContent=gameState.mode==="pvp"
        ?t("player_wins",{n:winner}):(winner===1?t("victory"):t("defeat"));
    document.getElementById("end-sub").textContent=
        t("turn")+" "+gameState.turn+" — "+
        gameState.camps.filter(c=>c.owner===winner).length+" "+t("camps_conquered");
    playSound(winner===1?"victory":"defeat");
    document.getElementById("screen-game").style.display="none";
    document.getElementById("screen-end").style.display="flex";
}

async function showLeaderboard() {
    const panel=document.getElementById("leaderboard-panel");
    panel.style.display=panel.style.display==="none"?"block":"none";
    if(panel.style.display==="none") return;
    const res=await fetch("http://localhost:5000/leaderboard");
    const data=await res.json();
    const table=document.getElementById("leaderboard-table");
    if(data.length===0){
        table.innerHTML="<tr><td colspan='4' style='text-align:center;color:#666;padding:10px'>Aucun score</td></tr>";
        return;
    }
    table.innerHTML=`
        <tr style='color:#ffd700'>
            <td style='padding:4px 8px'>#</td>
            <td style='padding:4px 8px'>Nom</td>
            <td style='padding:4px 8px'>Victoires</td>
            <td style='padding:4px 8px'>Camps</td>
        </tr>
        ${data.map((p,i)=>`<tr>
            <td style='padding:4px 8px;border-top:1px solid #2a3a2a;color:#aaa'>${i+1}</td>
            <td style='padding:4px 8px;border-top:1px solid #2a3a2a;color:#ddd'>${p.name}</td>
            <td style='padding:4px 8px;border-top:1px solid #2a3a2a;color:#aaa'>${p.wins}/${p.games}</td>
            <td style='padding:4px 8px;border-top:1px solid #2a3a2a;color:#aaa'>${p.camps}</td>
        </tr>`).join("")}
    `;
}

async function saveScore(winner,camps) {
    const name=gameState.mode==="pvp"
        ?(winner===1?"Joueur 1":"Joueur 2")
        :(winner===1?"Joueur":"IA");
    await fetch("http://localhost:5000/leaderboard/add",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({name,winner,turns:gameState.turn,camps,mode:gameState.mode})
    });
}

applyLang();
