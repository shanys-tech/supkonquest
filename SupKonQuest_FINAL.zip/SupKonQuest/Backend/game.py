from map import Map
from player import Player
from unit import Unit, Archer, Tank, Mage, Assassin, Boat
from camp import Camp

UNIT_PRICES = {
    "Archer": 10,
    "Mage": 15,
    "Tank": 20,
    "Assassin": 12,
    "Boat": 15
}

class Game:
    def __init__(self, map):
        self.map = map
        self.players = []
        self.current_player = 0
        self.actions_left = 2
        self.events = []
        self.camps = []

    def add_event(self, event_type, data):
        self.events.append({"type": event_type, "data": data})

    def export_events(self):
        events = self.events.copy()
        self.events = []
        return events

    def export_state(self):
        return {
            "current_player": self.players[self.current_player].team,
            "actions_left": self.actions_left,
            "units": [
                {
                    "x": unit.x, "y": unit.y, "team": unit.team,
                    "health": unit.health, "type": unit.__class__.__name__,
                    "attack_range": unit.attack_range, "damage": unit.damage,
                    "passenger": unit.passenger.__class__.__name__
                        if isinstance(unit, Boat) and unit.passenger else None
                }
                for player in self.players for unit in player.units
            ],
            "obstacles": self.map.obstacles,
            "water": self.map.water,
            "camps": [
                {
                    "x": camp.x, "y": camp.y, "region": camp.region,
                    "owner": camp.owner, "income": camp.income, "is_port": camp.is_port
                }
                for camp in self.camps
            ]
        }

    def add_player(self, player):
        self.players.append(player)

    def add_camp(self, camp):
        self.camps.append(camp)

    def place_unit(self, unit, x, y):
        unit.x = x
        unit.y = y

    def move_unit(self, unit, new_x, new_y):
        if unit.team != self.players[self.current_player].team:
            return False
        distance = abs(unit.x - new_x) + abs(unit.y - new_y)
        if distance > 3:
            return False
        if self.map.is_obstacle(new_x, new_y):
            return False
        if self.map.is_water(new_x, new_y) and not isinstance(unit, Boat):
            return False
        if isinstance(unit, Boat) and not self.map.is_water(new_x, new_y):
            is_port = any(c.x == new_x and c.y == new_y and c.is_port for c in self.camps)
            if not is_port:
                return False
        for player in self.players:
            for u in player.units:
                if u.x == new_x and u.y == new_y:
                    return False
        if 0 <= new_x < self.map.width and 0 <= new_y < self.map.height:
            old_pos = (unit.x, unit.y)
            unit.x = new_x
            unit.y = new_y
            self.add_event("move", {"from": old_pos, "to": (new_x, new_y), "unit": unit.__class__.__name__})
            for camp in self.camps:
                if camp.x == new_x and camp.y == new_y:
                    if camp.owner != unit.team:
                        self.capture_camp(unit, camp)
            self.use_action(unit.move_cost)
            return True
        return False

    def embark(self, unit, boat):
        if unit.team != self.players[self.current_player].team:
            return False
        distance = abs(unit.x - boat.x) + abs(unit.y - boat.y)
        if distance > 1:
            return False
        is_port = any(c.x == boat.x and c.y == boat.y and c.is_port for c in self.camps)
        if not is_port and not self.map.is_water(boat.x, boat.y):
            return False
        success = boat.embark(unit)
        if success:
            for player in self.players:
                if unit in player.units:
                    player.units.remove(unit)
                    break
            self.add_event("embark", {"unit": unit.__class__.__name__, "boat": (boat.x, boat.y), "team": unit.team})
            return True
        return False

    def disembark(self, boat, new_x, new_y):
        if boat.team != self.players[self.current_player].team:
            return False
        if boat.passenger is None:
            return False
        distance = abs(boat.x - new_x) + abs(boat.y - new_y)
        if distance > 1:
            return False
        if self.map.is_water(new_x, new_y) or self.map.is_obstacle(new_x, new_y):
            return False
        for player in self.players:
            for u in player.units:
                if u.x == new_x and u.y == new_y:
                    return False
        unit = boat.disembark()
        unit.x = new_x
        unit.y = new_y
        for player in self.players:
            if player.team == unit.team:
                player.add_unit(unit)
                break
        self.add_event("disembark", {"unit": unit.__class__.__name__, "position": (new_x, new_y), "team": unit.team})
        return True

    def buy_unit(self, unit_type, camp):
        player = self.players[self.current_player]
        if camp.owner != player.team:
            return False
        if unit_type not in UNIT_PRICES:
            return False
        price = UNIT_PRICES[unit_type]
        if player.money < price:
            return False
        for p in self.players:
            for u in p.units:
                if u.x == camp.x and u.y == camp.y:
                    return False
        unit_classes = {"Archer": Archer, "Mage": Mage, "Tank": Tank, "Assassin": Assassin, "Boat": Boat}
        new_unit = unit_classes[unit_type](camp.x, camp.y, team=player.team)
        player.add_unit(new_unit)
        player.money -= price
        self.add_event("buy", {"team": player.team, "unit": unit_type, "position": (camp.x, camp.y), "money_left": player.money})
        return new_unit

    def capture_camp(self, unit, camp):
        if camp.owner is not None:
            for player in self.players:
                if player.team == camp.owner:
                    player.remove_camp(camp)
                    break
        camp.owner = unit.team
        for player in self.players:
            if player.team == unit.team:
                player.add_camp(camp)
                break
        self.add_event("capture", {"camp": (camp.x, camp.y), "new_owner": unit.team})
        winner = self.check_winner()
        if winner:
            self.add_event("victory", {"winner": winner, "reason": "camps"})

    def check_region_bonus(self):
        regions = {}
        for camp in self.camps:
            if camp.region not in regions:
                regions[camp.region] = []
            regions[camp.region].append(camp)
        for region, camps in regions.items():
            owners = set(camp.owner for camp in camps)
            if len(owners) == 1 and None not in owners:
                owner_team = list(owners)[0]
                bonus = len(camps) * 3
                for player in self.players:
                    if player.team == owner_team:
                        player.money += bonus
                        self.add_event("region_bonus", {"team": owner_team, "region": region, "bonus": bonus})

    def collect_income(self):
        for player in self.players:
            for camp in player.camps:
                player.money += camp.income
            self.add_event("income", {"team": player.team, "money": player.money})
        self.check_region_bonus()

    def has_line_of_sight(self, x1, y1, x2, y2):
        dx = x2 - x1
        dy = y2 - y1
        steps = max(abs(dx), abs(dy))
        if steps == 0:
            return True
        for i in range(1, steps):
            x = round(x1 + dx * i / steps)
            y = round(y1 + dy * i / steps)
            if self.map.is_obstacle(x, y):
                return False
        return True

    def attack_unit(self, attacker, target):
        if attacker.team != self.players[self.current_player].team:
            return False
        if hasattr(attacker, "forced_target") and attacker.forced_target is not None:
            if target != attacker.forced_target:
                return False
        distance = abs(attacker.x - target.x) + abs(attacker.y - target.y)
        if distance > attacker.attack_range:
            return False
        if not self.has_line_of_sight(attacker.x, attacker.y, target.x, target.y):
            return False
        target.take_damage(attacker.damage)
        self.add_event("attack", {"attacker": (attacker.x, attacker.y), "target": (target.x, target.y), "damage": attacker.damage})
        if target.is_dead():
            for player in self.players:
                if target in player.units:
                    player.units.remove(target)
                    break
            self.add_event("death", {"unit": target.__class__.__name__, "position": (target.x, target.y)})
            winner = self.check_winner()
            if winner:
                self.add_event("victory", {"winner": winner, "reason": "unites"})
        self.use_action(attacker.attack_cost)
        return True

    def use_special(self, unit):
        if unit.team != self.players[self.current_player].team:
            return False
        if self.actions_left < unit.special_cost:
            return False
        area = unit.get_area_of_effect()
        success = unit.special(self)
        if success:
            self.add_event("special", {"unit": (unit.x, unit.y), "ability": unit.__class__.__name__, "area": area})
            self.use_action(unit.special_cost)
            return True
        return False

    def next_turn(self):
        self.current_player = (self.current_player + 1) % len(self.players)

    def start_turn(self):
        self.actions_left = 2
        self.collect_income()

    def use_action(self, amount=1):
        self.actions_left -= amount
        if self.actions_left <= 0:
            self.next_turn()
            self.start_turn()

    def check_winner(self):
        players_alive = [p for p in self.players if len(p.units) > 0]
        if len(players_alive) == 1:
            return players_alive[0].team
        non_neutral_camps = [c for c in self.camps if c.owner is not None]
        if len(non_neutral_camps) == 0:
            return None
        owners = set(c.owner for c in non_neutral_camps)
        if len(owners) == 1:
            return list(owners)[0]
        return None
