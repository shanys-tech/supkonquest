import itertools

class Camp:
    _id_counter = itertools.count()

    def __init__(self, x, y, region, income=5, is_port=False):
        self.id = next(Camp._id_counter)
        self.x = x
        self.y = y
        self.region = region
        self.income = income
        self.owner = None
        self.is_port = is_port

    def to_dict(self):
        return {
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "region": self.region,
            "income": self.income,
            "owner": self.owner,
            "is_port": self.is_port
        }
