import itertools

_unit_id_counter = itertools.count()

class Unit:
    def __init__(self, x, y, health, team, damage=5):
        self.id = next(_unit_id_counter)
        self.x = x
        self.y = y
        self.health = health
        self.team = team
        self.attack_range = 1
        self.damage = damage
        self.move_cost = 1
        self.attack_cost = 1
        self.special_cost = 2
        self.forced_target = None

    def take_damage(self, amount):
        self.health -= amount

    def is_dead(self):
        return self.health <= 0

    def get_area_of_effect(self):
        return []

    def special(self, game):
        return False


class Archer(Unit):
    def __init__(self, x, y, team):
        super().__init__(x, y, health=8, team=team, damage=3)
        self.attack_range = 3

    def get_area_of_effect(self):
        return [(self.x, y) for y in range(10)] + [(x, self.y) for x in range(10)]

    def special(self, game):
        hits = 0
        for player in game.players:
            for unit in player.units:
                if unit.team != self.team:
                    if unit.x == self.x or unit.y == self.y:
                        unit.take_damage(self.damage)
                        hits += 1
                        if hits == 2:
                            return True
        return hits > 0


class Tank(Unit):
    def __init__(self, x, y, team):
        super().__init__(x, y, health=20, team=team, damage=2)
        self.move_cost = 2

    def get_area_of_effect(self):
        return [
            (self.x + dx, self.y + dy)
            for dx in range(-2, 3)
            for dy in range(-2, 3)
            if abs(dx) + abs(dy) <= 2
        ]

    def special(self, game):
        for player in game.players:
            for unit in player.units:
                if unit.team != self.team:
                    distance = abs(unit.x - self.x) + abs(unit.y - self.y)
                    if distance <= 2:
                        unit.forced_target = self
        return True


class Mage(Unit):
    def __init__(self, x, y, team):
        super().__init__(x, y, health=6, team=team, damage=5)
        self.attack_range = 2

    def get_area_of_effect(self):
        return [
            (self.x + dx, self.y + dy)
            for dx in range(-2, 3)
            for dy in range(-2, 3)
            if abs(dx) + abs(dy) <= 2
        ]

    def special(self, game):
        for player in game.players:
            for unit in player.units:
                if unit.team != self.team:
                    distance = abs(unit.x - self.x) + abs(unit.y - self.y)
                    if distance <= 2:
                        unit.take_damage(self.damage)
        return True


class Assassin(Unit):
    def __init__(self, x, y, team):
        super().__init__(x, y, health=7, team=team, damage=8)

    def get_area_of_effect(self):
        return [
            (self.x + 1, self.y),
            (self.x - 1, self.y),
            (self.x, self.y + 1),
            (self.x, self.y - 1)
        ]

    def special(self, game):
        for player in game.players:
            for unit in player.units:
                if unit.team != self.team:
                    distance = abs(unit.x - self.x) + abs(unit.y - self.y)
                    if distance == 1:
                        unit.take_damage(self.damage * 2)
                        return True
        return False


class Boat(Unit):
    def __init__(self, x, y, team):
        super().__init__(x, y, health=10, team=team, damage=2)
        self.passenger = None

    def embark(self, unit):
        if self.passenger is None:
            self.passenger = unit
            return True
        return False

    def disembark(self):
        unit = self.passenger
        self.passenger = None
        return unit
