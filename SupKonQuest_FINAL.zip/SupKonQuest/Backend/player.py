class Player:
    def __init__(self, team):
        self.team = team
        self.units = []
        self.money = 0
        self.camps = []

    def add_unit(self, unit):
        self.units.append(unit)

    def add_camp(self, camp):
        self.camps.append(camp)

    def remove_camp(self, camp):
        if camp in self.camps:
            self.camps.remove(camp)
