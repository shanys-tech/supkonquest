import random

class AI:
    def __init__(self, player, game):
        self.player = player
        self.game = game

    def play_turn(self):
        units = self.player.units.copy()
        for unit in units:
            if unit not in self.player.units:
                continue
            attacked = self.try_attack(unit)
            if not attacked:
                captured = self.try_capture(unit)
                if not captured:
                    self.try_move(unit)

    def try_attack(self, unit):
        enemies = [
            u for p in self.game.players
            for u in p.units
            if p.team != self.player.team
        ]
        for enemy in enemies:
            distance = abs(unit.x - enemy.x) + abs(unit.y - enemy.y)
            if distance <= unit.attack_range:
                if self.game.has_line_of_sight(unit.x, unit.y, enemy.x, enemy.y):
                    result = self.game.attack_unit(unit, enemy)
                    if result:
                        return True
        return False

    def try_capture(self, unit):
        targets = [
            camp for camp in self.game.camps
            if camp.owner != self.player.team
        ]
        if not targets:
            return False
        targets.sort(key=lambda c: abs(unit.x - c.x) + abs(unit.y - c.y))
        nearest = targets[0]
        distance = abs(unit.x - nearest.x) + abs(unit.y - nearest.y)
        if distance <= 3:
            result = self.game.move_unit(unit, nearest.x, nearest.y)
            if result:
                return True
        return False

    def try_move(self, unit):
        enemies = [
            u for p in self.game.players
            for u in p.units
            if p.team != self.player.team
        ]
        camps = [
            camp for camp in self.game.camps
            if camp.owner != self.player.team
        ]
        targets = enemies + camps
        if not targets:
            return False
        targets.sort(key=lambda t: abs(unit.x - t.x) + abs(unit.y - t.y))
        target = targets[0]
        dx = target.x - unit.x
        dy = target.y - unit.y
        moves = []
        if dx != 0:
            moves.append((unit.x + (1 if dx > 0 else -1), unit.y))
        if dy != 0:
            moves.append((unit.x, unit.y + (1 if dy > 0 else -1)))
        random.shuffle(moves)
        for new_x, new_y in moves:
            result = self.game.move_unit(unit, new_x, new_y)
            if result:
                return True
        return False
