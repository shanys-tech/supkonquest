from flask import Flask, jsonify, request
from flask_cors import CORS
import random
import copy
import json
import os

app = Flask(__name__)
CORS(app)

MAP_W = 16
MAP_H = 12

MAPS = {
    "europe": {
        "name": "Europe Medievale",
        "water": [
            {"x": 6, "y": 4}, {"x": 7, "y": 4}, {"x": 8, "y": 4},
            {"x": 6, "y": 5}, {"x": 7, "y": 5}
        ],
        "obstacles": [
            {"x": 2, "y": 6}, {"x": 3, "y": 6},
            {"x": 11, "y": 3}, {"x": 12, "y": 3},
            {"x": 9, "y": 9}, {"x": 10, "y": 9}
        ],
        "camps": [
            {"x": 2,  "y": 2,  "owner": None, "id": 0, "is_port": False},
            {"x": 13, "y": 9,  "owner": None, "id": 1, "is_port": False},
            {"x": 7,  "y": 1,  "owner": None, "id": 2, "is_port": False},
            {"x": 7,  "y": 10, "owner": None, "id": 3, "is_port": False},
            {"x": 1,  "y": 9,  "owner": None, "id": 4, "is_port": False},
            {"x": 13, "y": 2,  "owner": None, "id": 5, "is_port": False},
            {"x": 5,  "y": 4,  "owner": None, "id": 6, "is_port": True},
        ],
        "regions": [
            {"name": "Nord", "camps": [2, 5], "bonus": 10},
            {"name": "Centre", "camps": [0, 1], "bonus": 15},
            {"name": "Sud", "camps": [3, 4], "bonus": 10},
        ],
        "spawn_p1": {"x": 3, "y": 3},
        "spawn_p2": {"x": 12, "y": 8},
    },
    "afrique": {
        "name": "Afrique Desertique",
        "water": [],
        "obstacles": [
            {"x": 4,  "y": 3}, {"x": 5,  "y": 3}, {"x": 6, "y": 3},
            {"x": 9,  "y": 8}, {"x": 10, "y": 8}, {"x": 11, "y": 8},
            {"x": 7,  "y": 5}, {"x": 8,  "y": 6},
            {"x": 2,  "y": 9}, {"x": 13, "y": 2}
        ],
        "camps": [
            {"x": 1,  "y": 1,  "owner": None, "id": 0, "is_port": False},
            {"x": 14, "y": 10, "owner": None, "id": 1, "is_port": False},
            {"x": 7,  "y": 0,  "owner": None, "id": 2, "is_port": False},
            {"x": 7,  "y": 11, "owner": None, "id": 3, "is_port": False},
            {"x": 0,  "y": 6,  "owner": None, "id": 4, "is_port": False},
            {"x": 14, "y": 5,  "owner": None, "id": 5, "is_port": False},
        ],
        "regions": [
            {"name": "Nord Afrique", "camps": [2, 0], "bonus": 10},
            {"name": "Centre Afrique", "camps": [4, 5], "bonus": 15},
            {"name": "Sud Afrique", "camps": [3, 1], "bonus": 10},
        ],
        "spawn_p1": {"x": 2, "y": 2},
        "spawn_p2": {"x": 13, "y": 9},
    },
    "amerique": {
        "name": "Archipel Americain",
        "water": [
            {"x": 5,  "y": 0}, {"x": 5, "y": 1}, {"x": 5, "y": 2},
            {"x": 5,  "y": 3}, {"x": 5, "y": 4}, {"x": 5, "y": 5},
            {"x": 5,  "y": 6}, {"x": 5, "y": 7}, {"x": 5, "y": 8},
            {"x": 10, "y": 3}, {"x": 10, "y": 4}, {"x": 10, "y": 5},
            {"x": 10, "y": 6}, {"x": 10, "y": 7}, {"x": 10, "y": 8},
            {"x": 10, "y": 9}, {"x": 10, "y": 10}, {"x": 10, "y": 11},
            {"x": 6,  "y": 9}, {"x": 7, "y": 9}, {"x": 8, "y": 9},
            {"x": 9,  "y": 9}
        ],
        "obstacles": [
            {"x": 3, "y": 5}, {"x": 12, "y": 6}
        ],
        "camps": [
            {"x": 2,  "y": 2,  "owner": None, "id": 0, "is_port": False},
            {"x": 13, "y": 9,  "owner": None, "id": 1, "is_port": False},
            {"x": 2,  "y": 9,  "owner": None, "id": 2, "is_port": False},
            {"x": 13, "y": 2,  "owner": None, "id": 3, "is_port": False},
            {"x": 7,  "y": 5,  "owner": None, "id": 4, "is_port": False},
            {"x": 4,  "y": 3,  "owner": None, "id": 5, "is_port": True},
            {"x": 11, "y": 8,  "owner": None, "id": 6, "is_port": True},
        ],
        "regions": [
            {"name": "Nord Amerique", "camps": [0, 3], "bonus": 12},
            {"name": "Sud Amerique", "camps": [1, 2], "bonus": 12},
        ],
        "spawn_p1": {"x": 3, "y": 3},
        "spawn_p2": {"x": 13, "y": 8},
    }
}

UNIT_STATS = {
    "archer":   {"hp": 100, "damage": 40, "range": 3, "speed": 2, "cost": 50},
    "tank":     {"hp": 150, "damage": 30, "range": 1, "speed": 1, "cost": 80},
    "mage":     {"hp": 90,  "damage": 55, "range": 2, "speed": 2, "cost": 70},
    "assassin": {"hp": 80,  "damage": 65, "range": 1, "speed": 3, "cost": 60},
    "infantry": {"hp": 100, "damage": 35, "range": 1, "speed": 2, "cost": 40},
    "boat":     {"hp": 120, "damage": 25, "range": 2, "speed": 2, "cost": 60},
}

game_state = {}
LEADERBOARD_FILE = "leaderboard.json"

def load_leaderboard():
    if os.path.exists(LEADERBOARD_FILE):
        with open(LEADERBOARD_FILE, "r") as f:
            return json.load(f)
    return []

def save_leaderboard_file(data):
    with open(LEADERBOARD_FILE, "w") as f:
        json.dump(data, f)

leaderboard = load_leaderboard()

def make_initial_state(map_name, mode, ai_level=1):
    m = copy.deepcopy(MAPS[map_name])
    camps = m["camps"]
    camps[0]["owner"] = 1
    camps[1]["owner"] = 2
    sp1 = m["spawn_p1"]
    sp2 = m["spawn_p2"]
    return {
        "map_name": map_name,
        "mode": mode,
        "ai_level": ai_level,
        "current_player": 1,
        "turn": 1,
        "gold": {1: 100, 2: 100},
        "water": m["water"],
        "obstacles": m["obstacles"],
        "camps": camps,
        "regions": m.get("regions", []),
        "units": [
            {"id": 1, "x": sp1["x"], "y": sp1["y"], "type": "infantry", "team": 1, "hp": 100, "maxhp": 100, "moved": False, "spell_used": False, "shield": False, "passenger": None},
            {"id": 2, "x": sp2["x"], "y": sp2["y"], "type": "infantry", "team": 2, "hp": 100, "maxhp": 100, "moved": False, "spell_used": False, "shield": False, "passenger": None},
        ]
    }

def is_water(state, x, y):
    return any(w["x"] == x and w["y"] == y for w in state["water"])

def is_blocked(state, x, y):
    if x < 0 or y < 0 or x >= MAP_W or y >= MAP_H:
        return True
    return (is_water(state, x, y) or
            any(o["x"] == x and o["y"] == y for o in state["obstacles"]))

def is_blocked_for_boat(state, x, y):
    if x < 0 or y < 0 or x >= MAP_W or y >= MAP_H:
        return True
    if any(o["x"] == x and o["y"] == y for o in state["obstacles"]):
        return True
    # Le bateau peut aller sur l'eau ou sur un port
    if is_water(state, x, y):
        return False
    if any(c["x"] == x and c["y"] == y and c.get("is_port") for c in state["camps"]):
        return False
    return True  # Terre sans port = bloqué pour bateau

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def get_new_unit_id(state):
    if not state["units"]:
        return 1
    return max(u["id"] for u in state["units"]) + 1

def manhattan(a, b):
    return abs(a["x"] - b["x"]) + abs(a["y"] - b["y"])

def try_capture_camp(state, unit):
    for c in state["camps"]:
        if c["x"] == unit["x"] and c["y"] == unit["y"] and c["owner"] != unit["team"]:
            c["owner"] = unit["team"]
            return True
    return False

def camp_tower_attack(state):
    results = []
    for c in state["camps"]:
        if c["owner"] is None:
            continue
        for u in state["units"]:
            if u["team"] == c["owner"]:
                continue
            if manhattan(c, u) <= 2:
                u["hp"] -= 15
                results.append("Camp ({},{}) attaque unite #{} (-15 PV)".format(c["x"], c["y"], u["id"]))
    state["units"] = [u for u in state["units"] if u["hp"] > 0]
    return results

def apply_region_bonuses(state):
    results = []
    for region in state.get("regions", []):
        for team in [1, 2]:
            camp_ids = region["camps"]
            if all(state["camps"][cid]["owner"] == team for cid in camp_ids):
                bonus = region["bonus"]
                state["gold"][team] += bonus
                results.append("Region {} : +{} or au joueur {}".format(region["name"], bonus, team))
    return results

@app.route("/new_game", methods=["POST"])
def new_game():
    try:
        data     = request.json
        map_name = data.get("map", "europe")
        mode     = data.get("mode", "pve")
        ai_level = int(data.get("ai_level", 1))
        if map_name not in MAPS:
            map_name = "europe"
        game_state.clear()
        game_state.update(make_initial_state(map_name, mode, ai_level))
        return jsonify({"status": "ok", "state": game_state})
    except Exception as e:
        return jsonify({"status": "error", "msg": str(e)}), 500

@app.route("/state")
def state():
    if not game_state:
        game_state.update(make_initial_state("europe", "pve", 1))
    return jsonify(game_state)

@app.route("/move_unit", methods=["POST"])
def move_unit():
    data    = request.json
    unit_id = data["id"]
    new_x   = clamp(data["x"], 0, MAP_W - 1)
    new_y   = clamp(data["y"], 0, MAP_H - 1)

    unit = next((u for u in game_state["units"] if u["id"] == unit_id), None)
    if not unit:
        return jsonify({"status": "error", "msg": "Unite introuvable"})

    # Bateau : peut aller sur eau et ports
    if unit["type"] == "boat":
        if is_blocked_for_boat(game_state, new_x, new_y):
            return jsonify({"status": "error", "msg": "Case bloquee pour le bateau"})
    else:
        # Unité terrestre : ne peut pas aller sur l'eau sauf si bateau present
        if is_water(game_state, new_x, new_y):
            # Vérifier si un bateau allié est sur cette case
            boat = next((u for u in game_state["units"] if u["x"] == new_x and u["y"] == new_y and u["type"] == "boat" and u["team"] == unit["team"]), None)
            if boat:
                # Embarquer sur le bateau
                if boat.get("passenger") is None:
                    boat["passenger"] = unit_id
                    game_state["units"] = [u for u in game_state["units"] if u["id"] != unit_id]
                    return jsonify({"status": "ok", "captured": False, "embarked": True, "boat_id": boat["id"]})
                else:
                    return jsonify({"status": "error", "msg": "Bateau deja occupe"})
            return jsonify({"status": "error", "msg": "Case eau - utilisez un bateau"})

        if is_blocked(game_state, new_x, new_y):
            return jsonify({"status": "error", "msg": "Case bloquee"})

    if any(u["x"] == new_x and u["y"] == new_y for u in game_state["units"] if u["id"] != unit_id):
        return jsonify({"status": "error", "msg": "Case occupee"})

    unit["x"] = new_x
    unit["y"] = new_y
    unit["moved"] = True
    captured = try_capture_camp(game_state, unit)
    return jsonify({"status": "ok", "captured": captured, "embarked": False})

@app.route("/disembark", methods=["POST"])
def disembark():
    data    = request.json
    boat_id = data["boat_id"]
    new_x   = clamp(data["x"], 0, MAP_W - 1)
    new_y   = clamp(data["y"], 0, MAP_H - 1)

    boat = next((u for u in game_state["units"] if u["id"] == boat_id), None)
    if not boat or boat["type"] != "boat":
        return jsonify({"status": "error", "msg": "Bateau introuvable"})
    if boat.get("passenger") is None:
        return jsonify({"status": "error", "msg": "Aucun passager"})
    if is_water(game_state, new_x, new_y) or is_blocked(game_state, new_x, new_y):
        return jsonify({"status": "error", "msg": "Debarquement impossible ici"})
    if any(u["x"] == new_x and u["y"] == new_y for u in game_state["units"]):
        return jsonify({"status": "error", "msg": "Case occupee"})

    passenger_id = boat["passenger"]
    # Recréer l'unité passagère
    stats = UNIT_STATS.get("infantry", {})
    # On cherche dans l'historique (on stocke le type)
    unit_type = boat.get("passenger_type", "infantry")
    unit_hp   = boat.get("passenger_hp", 100)
    stats     = UNIT_STATS.get(unit_type, UNIT_STATS["infantry"])

    new_unit = {
        "id": passenger_id,
        "x": new_x, "y": new_y,
        "type": unit_type,
        "team": boat["team"],
        "hp": unit_hp, "maxhp": stats["hp"],
        "moved": False, "spell_used": False, "shield": False, "passenger": None
    }
    game_state["units"].append(new_unit)
    boat["passenger"] = None
    boat["passenger_type"] = None
    boat["passenger_hp"] = None

    captured = try_capture_camp(game_state, new_unit)
    return jsonify({"status": "ok", "captured": captured})

@app.route("/attack", methods=["POST"])
def attack():
    data        = request.json
    attacker_id = data["attacker"]
    target_id   = data["target"]
    attacker = next((u for u in game_state["units"] if u["id"] == attacker_id), None)
    target   = next((u for u in game_state["units"] if u["id"] == target_id), None)
    if not attacker or not target:
        return jsonify({"status": "error", "msg": "Unite introuvable"})
    rng  = UNIT_STATS.get(attacker["type"], {}).get("range", 1)
    dist = manhattan(attacker, target)
    if dist > rng:
        return jsonify({"status": "error", "msg": "Cible hors portee"})
    dmg = UNIT_STATS.get(attacker["type"], {}).get("damage", 30)
    if target.get("shield"):
        dmg = dmg // 2
    target["hp"] -= dmg
    killed = False
    if target["hp"] <= 0:
        game_state["units"] = [u for u in game_state["units"] if u["id"] != target_id]
        for c in game_state["camps"]:
            if c["x"] == target["x"] and c["y"] == target["y"]:
                c["owner"] = None
        killed = True
    return jsonify({"status": "ok", "damage": dmg, "killed": killed})

@app.route("/use_spell", methods=["POST"])
def use_spell():
    data      = request.json
    unit_id   = data["id"]
    target_id = data.get("target_id")
    unit = next((u for u in game_state["units"] if u["id"] == unit_id), None)
    if not unit:
        return jsonify({"status": "error", "msg": "Unite introuvable"})
    if unit.get("spell_used"):
        return jsonify({"status": "error", "msg": "Sort deja utilise ce tour"})
    result_msg = ""
    if unit["type"] == "archer":
        target = next((u for u in game_state["units"] if u["id"] == target_id), None)
        if not target:
            return jsonify({"status": "error", "msg": "Cible introuvable"})
        rng = UNIT_STATS["archer"]["range"] + 1
        if manhattan(unit, target) > rng:
            return jsonify({"status": "error", "msg": "Cible hors portee"})
        dmg = UNIT_STATS["archer"]["damage"] * 2
        target["hp"] -= dmg
        if target["hp"] <= 0:
            game_state["units"] = [u for u in game_state["units"] if u["id"] != target_id]
        result_msg = "Tir de precision ! -{} PV".format(dmg)
    elif unit["type"] == "mage":
        total_dmg = 0
        to_remove = []
        for u in game_state["units"]:
            if u["team"] != unit["team"] and manhattan(unit, u) <= 2:
                dmg = 40
                u["hp"] -= dmg
                total_dmg += dmg
                if u["hp"] <= 0:
                    to_remove.append(u["id"])
        game_state["units"] = [u for u in game_state["units"] if u["id"] not in to_remove]
        result_msg = "Boule de feu ! -{} PV total".format(total_dmg)
    elif unit["type"] == "tank":
        unit["shield"] = True
        result_msg = "Bouclier active ! -50% degats ce tour"
    elif unit["type"] == "assassin":
        target = next((u for u in game_state["units"] if u["id"] == target_id), None)
        if not target:
            return jsonify({"status": "error", "msg": "Cible introuvable"})
        possible = [(target["x"]+1,target["y"]),(target["x"]-1,target["y"]),(target["x"],target["y"]+1),(target["x"],target["y"]-1)]
        for px, py in possible:
            if not is_blocked(game_state, px, py) and not any(u["x"]==px and u["y"]==py for u in game_state["units"] if u["id"]!=unit_id):
                unit["x"] = px; unit["y"] = py
                break
        dmg = UNIT_STATS["assassin"]["damage"] + 30
        target["hp"] -= dmg
        if target["hp"] <= 0:
            game_state["units"] = [u for u in game_state["units"] if u["id"] != target_id]
        result_msg = "Frappe mortelle ! -{} PV".format(dmg)
    elif unit["type"] == "infantry":
        healed = 0
        for u in game_state["units"]:
            if u["team"] == unit["team"] and u["id"] != unit_id and manhattan(unit, u) <= 1:
                u["hp"] = min(u["hp"] + 10, u.get("maxhp", 100))
                healed += 1
        result_msg = "Cri de guerre ! +10 PV a {} allie(s)".format(healed)
    unit["spell_used"] = True
    return jsonify({"status": "ok", "msg": result_msg})

@app.route("/produce_unit", methods=["POST"])
def produce_unit():
    data      = request.json
    camp_x    = data["x"]
    camp_y    = data["y"]
    unit_type = data["type"]
    team      = int(data["team"])
    camp = next((c for c in game_state["camps"] if c["x"] == camp_x and c["y"] == camp_y), None)
    if not camp or camp["owner"] != team:
        return jsonify({"status": "error", "msg": "Camp non controle"})

    # Les bateaux ne peuvent être produits que depuis un port
    if unit_type == "boat" and not camp.get("is_port"):
        return jsonify({"status": "error", "msg": "Les bateaux se produisent depuis un port"})

    cost = UNIT_STATS.get(unit_type, {}).get("cost", 50)
    if game_state["gold"][team] < cost:
        return jsonify({"status": "error", "msg": "Pas assez d or"})

    # Pour un bateau : spawn sur l'eau adjacente au port
    if unit_type == "boat":
        possible = [(camp_x+1,camp_y),(camp_x-1,camp_y),(camp_x,camp_y+1),(camp_x,camp_y-1)]
        spawn = None
        for sx, sy in possible:
            if (0 <= sx < MAP_W and 0 <= sy < MAP_H and
                    is_water(game_state, sx, sy) and
                    not any(u["x"] == sx and u["y"] == sy for u in game_state["units"])):
                spawn = (sx, sy)
                break
        if not spawn:
            return jsonify({"status": "error", "msg": "Pas d eau adjacente au port"})
    else:
        possible = [(camp_x+1,camp_y),(camp_x-1,camp_y),(camp_x,camp_y+1),(camp_x,camp_y-1)]
        spawn = None
        for sx, sy in possible:
            if (0 <= sx < MAP_W and 0 <= sy < MAP_H and
                    not is_blocked(game_state, sx, sy) and
                    not any(u["x"] == sx and u["y"] == sy for u in game_state["units"])):
                spawn = (sx, sy)
                break
        if not spawn:
            return jsonify({"status": "error", "msg": "Aucune place disponible"})

    stats    = UNIT_STATS[unit_type]
    new_unit = {
        "id": get_new_unit_id(game_state),
        "x": spawn[0], "y": spawn[1],
        "type": unit_type, "team": team,
        "hp": stats["hp"], "maxhp": stats["hp"],
        "moved": False, "spell_used": False, "shield": False, "passenger": None
    }
    game_state["units"].append(new_unit)
    game_state["gold"][team] -= cost
    return jsonify({"status": "ok", "unit": new_unit})

@app.route("/end_turn", methods=["POST"])
def end_turn():
    for t in [1, 2]:
        owned = sum(1 for c in game_state["camps"] if c["owner"] == t)
        game_state["gold"][t] += 15 * max(owned, 1)
    region_log = apply_region_bonuses(game_state)
    tower_log  = camp_tower_attack(game_state)
    for u in game_state["units"]:
        u["moved"]      = False
        u["spell_used"] = False
        u["shield"]     = False
    game_state["turn"] += 1
    if game_state["mode"] == "pvp":
        game_state["current_player"] = 2 if game_state["current_player"] == 1 else 1
    return jsonify({"status": "ok", "tower_log": tower_log, "region_log": region_log})

@app.route("/ai_turn", methods=["POST"])
def ai_turn():
    level        = game_state.get("ai_level", 1)
    ai_units     = [u for u in game_state["units"] if u["team"] == 2]
    player_units = [u for u in game_state["units"] if u["team"] == 1]
    log = []

    for ai in ai_units:
        if level == 1:
            dx, dy = random.choice([(1,0),(-1,0),(0,1),(0,-1),(0,0)])
            nx = clamp(ai["x"]+dx, 0, MAP_W-1)
            ny = clamp(ai["y"]+dy, 0, MAP_H-1)
            if not is_blocked(game_state, nx, ny) and not any(u["x"]==nx and u["y"]==ny for u in game_state["units"] if u["id"]!=ai["id"]):
                ai["x"] = nx; ai["y"] = ny
            try_capture_camp(game_state, ai)
            rng = UNIT_STATS.get(ai["type"],{}).get("range",1)
            for p in list(player_units):
                if manhattan(ai, p) <= rng:
                    dmg = UNIT_STATS.get(ai["type"],{}).get("damage",25)
                    p["hp"] -= dmg
                    log.append("IA attaque #{} (-{})".format(p["id"], dmg))
            continue

        if level == 2:
            if ai["hp"] < 40:
                ai["x"] = clamp(ai["x"]+random.choice([-1,0,1]), 0, MAP_W-1)
                ai["y"] = clamp(ai["y"]+random.choice([-1,0,1]), 0, MAP_H-1)
                continue
            neutral_camps = [c for c in game_state["camps"] if c["owner"] != 2]
            target_camp   = min(neutral_camps, key=lambda c: manhattan(ai, c), default=None)
            target_unit   = min(player_units, key=lambda p: manhattan(ai, p), default=None) if player_units else None
            rng = UNIT_STATS.get(ai["type"],{}).get("range",1)
            if target_unit and manhattan(ai, target_unit) <= rng:
                dmg = UNIT_STATS.get(ai["type"],{}).get("damage",30)
                target_unit["hp"] -= dmg
                log.append("IA attaque #{} (-{})".format(target_unit["id"], dmg))
                if target_unit["hp"] <= 0:
                    game_state["units"] = [u for u in game_state["units"] if u["id"] != target_unit["id"]]
                    player_units = [u for u in game_state["units"] if u["team"] == 1]
                continue
            goal = target_camp if target_camp else target_unit
            if goal:
                dx = goal["x"]-ai["x"]; dy = goal["y"]-ai["y"]
                sx = clamp(ai["x"]+(1 if dx>0 else -1 if dx<0 else 0), 0, MAP_W-1)
                sy = clamp(ai["y"]+(1 if dy>0 else -1 if dy<0 else 0), 0, MAP_H-1)
                if not is_blocked(game_state, sx, sy) and not any(u["x"]==sx and u["y"]==sy for u in game_state["units"] if u["id"]!=ai["id"]):
                    ai["x"] = sx; ai["y"] = sy
                    try_capture_camp(game_state, ai)
            continue

        if level == 3:
            if ai["hp"] < 25:
                ally_camps = [c for c in game_state["camps"] if c["owner"] == 2]
                if ally_camps:
                    goal = min(ally_camps, key=lambda c: manhattan(ai, c))
                    dx = goal["x"]-ai["x"]; dy = goal["y"]-ai["y"]
                    sx = clamp(ai["x"]+(1 if dx>0 else -1 if dx<0 else 0), 0, MAP_W-1)
                    sy = clamp(ai["y"]+(1 if dy>0 else -1 if dy<0 else 0), 0, MAP_H-1)
                    if not is_blocked(game_state, sx, sy):
                        ai["x"] = sx; ai["y"] = sy
                continue
            ai_camp = next((c for c in game_state["camps"] if c["owner"]==2), None)
            if ai_camp and game_state["gold"][2] >= 60 and len(ai_units) < 5:
                possible = [(ai_camp["x"]+1,ai_camp["y"]),(ai_camp["x"]-1,ai_camp["y"]),(ai_camp["x"],ai_camp["y"]+1),(ai_camp["x"],ai_camp["y"]-1)]
                for sx, sy in possible:
                    if (0<=sx<MAP_W and 0<=sy<MAP_H and
                            not is_blocked(game_state,sx,sy) and
                            not any(u["x"]==sx and u["y"]==sy for u in game_state["units"])):
                        new_unit = {"id": get_new_unit_id(game_state), "x": sx, "y": sy, "type": "assassin", "team": 2, "hp": 80, "maxhp": 80, "moved": False, "spell_used": False, "shield": False, "passenger": None}
                        game_state["units"].append(new_unit)
                        game_state["gold"][2] -= 60
                        ai_units.append(new_unit)
                        log.append("IA produit un assassin")
                        break
            if player_units:
                target_unit = min(player_units, key=lambda p: p["hp"])
                rng = UNIT_STATS.get(ai["type"],{}).get("range",1)
                if manhattan(ai, target_unit) <= rng:
                    dmg = UNIT_STATS.get(ai["type"],{}).get("damage",30) + random.randint(0,10)
                    target_unit["hp"] -= dmg
                    log.append("IA attaque #{} (-{})".format(target_unit["id"], dmg))
                    if target_unit["hp"] <= 0:
                        game_state["units"] = [u for u in game_state["units"] if u["id"] != target_unit["id"]]
                        player_units = [u for u in game_state["units"] if u["team"] == 1]
                else:
                    dx = target_unit["x"]-ai["x"]; dy = target_unit["y"]-ai["y"]
                    sx = clamp(ai["x"]+(1 if dx>0 else -1 if dx<0 else 0), 0, MAP_W-1)
                    sy = clamp(ai["y"]+(1 if dy>0 else -1 if dy<0 else 0), 0, MAP_H-1)
                    if not is_blocked(game_state, sx, sy) and not any(u["x"]==sx and u["y"]==sy for u in game_state["units"] if u["id"]!=ai["id"]):
                        ai["x"] = sx; ai["y"] = sy
                        try_capture_camp(game_state, ai)

    owned = sum(1 for c in game_state["camps"] if c["owner"] == 2)
    game_state["gold"][2] += 15 * max(owned, 1)
    return jsonify({"status": "ok", "log": log})

@app.route("/leaderboard", methods=["GET"])
def get_leaderboard():
    return jsonify(sorted(leaderboard, key=lambda x: x["wins"], reverse=True))

@app.route("/leaderboard/add", methods=["POST"])
def add_score():
    data     = request.json
    name     = data.get("name", "Joueur")
    winner   = data.get("winner", 1)
    turns    = data.get("turns", 0)
    camps    = data.get("camps", 0)
    mode     = data.get("mode", "pve")
    existing = next((p for p in leaderboard if p["name"] == name), None)
    if existing:
        existing["wins"]  += 1 if winner == 1 else 0
        existing["games"] += 1
        existing["camps"] += camps
    else:
        leaderboard.append({
            "name":  name, "wins": 1 if winner == 1 else 0,
            "games": 1,    "camps": camps, "turns": turns, "mode": mode
        })
    save_leaderboard_file(leaderboard)
    return jsonify({"status": "ok"})

@app.route("/maps")
def get_maps():
    return jsonify([{"id": k, "name": v["name"]} for k, v in MAPS.items()])

if __name__ == "__main__":
    app.run(debug=True)
