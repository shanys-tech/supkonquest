class Map:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.obstacles = []
        self.water = []

    def add_obstacle(self, x, y):
        if 0 <= x < self.width and 0 <= y < self.height:
            self.obstacles.append((x, y))

    def is_obstacle(self, x, y):
        return (x, y) in self.obstacles

    def add_water(self, x, y):
        if 0 <= x < self.width and 0 <= y < self.height:
            self.water.append((x, y))

    def is_water(self, x, y):
        return (x, y) in self.water
