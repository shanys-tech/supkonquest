=== SupKonQuest — Jeu de strategie de conquete ===

LANCEMENT :

1. Terminal 1 — Backend :
   cd Backend
   pip install flask flask-cors
   python server.py
   -> Serveur sur http://127.0.0.1:5000

2. Terminal 2 — Frontend :
   cd Frontend
   python -m http.server 8080

3. Navigateur :
   http://localhost:8080

STRUCTURE :
   Backend/
     server.py  - Serveur Flask, API REST, logique du jeu, IA
     ai.py      - Classe AI (3 niveaux de difficulte)
     game.py    - Classe Game (moteur, actions, victoire)
     unit.py    - Classes Unit, Archer, Tank, Mage, Assassin, Boat
     camp.py    - Classe Camp (camps, ports, regions)
     map.py     - Classe Map (grille, obstacles, eau)
     player.py  - Classe Player (equipe, unites, argent)
   Frontend/
     index.html - Interface HTML
     game.js    - Logique client, rendu Canvas
     style.css  - Styles CSS
     sounds/    - Fichiers audio MP3 (à ajouter)
   docs/
     manuel_utilisateur.docx/.pdf
     documentation_technique.docx/.pdf
